# PANDUAN INSTALASI ANDROID — ENGLISH MASTERY 62 DAYS (1 Nov – 31 Des 2026)

Paket ini berisi **Aplikasi Mandiri Offline (PWA/WebAPK)** dan **Source Code Proyek Android Native (.APK)** lengkap dengan *Native Android Text-to-Speech (TTS) Bridge*, penyimpanan progres lokal permanen (`DOMStorage`), dan seluruh 61 hari kurikulum (610 kosakata, 305 soal kuis, audio dialog, speaking & writing checker).

---

## CARA 1: Instal Langsung di HP Android Tanpa Laptop (Paling Cepat — 30 Detik)

Anda tidak memerlukan laptop untuk memasang aplikasi ini ke daftar aplikasi (*App Drawer* / *Home Screen*) HP Android Anda:

1. Dari tampilan aplikasi di layar Anda, ketuk tombol **"🤖 Install Aplikasi Android"** di bagian atas Dashboard, lalu pilih **"📦 2. Unduh Aplikasi Offline (.html)"** (atau ekstrak file `app/src/main/assets/index.html` dari dalam file ZIP ini).
2. Buka file tersebut menggunakan **Google Chrome** di HP Android Anda.
3. Ketuk ikon **Titik Tiga (⋮)** di pojok kanan atas Chrome, lalu pilih **"Tambahkan ke layar utama" (Add to Home screen)** atau **"Install aplikasi" (Install app)**.
4. Aplikasi **English Mastery 62D** kini terpasang sebagai aplikasi mandiri di HP Android Anda, berjalan layar penuh (*standalone*), dan seluruh progres belajar Anda tersimpan otomatis!

---

## CARA 2: Kompilasi menjadi File `.APK` Native langsung dari HP (Tanpa Laptop via GitHub Cloud)

Jika Anda menginginkan file instalasi **`app-debug.apk`** murni tanpa menggunakan laptop:

1. Buat repositori baru (gratis) di [github.com](https://github.com) melalui browser HP Anda, lalu unggah (*upload*) seluruh isi folder ini.
2. Buka tab **Actions** di repositori GitHub Anda — workflow **Build Android APK (English Mastery 62 Days)** (`.github/workflows/build-apk.yml`) akan otomatis mengompilasi proyek Android ini di server cloud.
3. Setelah selesai (sekitar 2 menit), unduh file **`English-Mastery-62-Days-Android-APK`** (`app-debug.apk`) dan pasang langsung di HP Android Anda!

---

## CARA 3: Kompilasi `.APK` di Android Wilayah Lokal (HopWeb / Spck / Android Studio)

- **Di HP Android (Aplikasi HopWeb / Website-2-APK):** Pilih folder `app/src/main/assets/` (yang berisi `index.html`, `manifest.json`, `sw.js`, dan ikon) lalu ketuk **Export APK**.
- **Di Android Studio:** Buka folder ini sebagai proyek Android Studio lalu jalankan menu **Build → Build Bundle(s) / APK(s) → Build APK(s)**. File `.apk` Anda sudah dilengkapi jembatan suara `AndroidTTSBridge` (`MainActivity.java`) sehingga pelafalan bahasa Inggris menggunakan mesin suara bawaan Android secara *offline*.
